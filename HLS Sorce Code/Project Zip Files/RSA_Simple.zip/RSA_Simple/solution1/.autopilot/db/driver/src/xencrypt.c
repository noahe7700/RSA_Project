// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xencrypt.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XEncrypt_CfgInitialize(XEncrypt *InstancePtr, XEncrypt_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XEncrypt_Start(XEncrypt *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEncrypt_ReadReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_AP_CTRL) & 0x80;
    XEncrypt_WriteReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XEncrypt_IsDone(XEncrypt *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEncrypt_ReadReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XEncrypt_IsIdle(XEncrypt *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEncrypt_ReadReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XEncrypt_IsReady(XEncrypt *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XEncrypt_ReadReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XEncrypt_EnableAutoRestart(XEncrypt *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEncrypt_WriteReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XEncrypt_DisableAutoRestart(XEncrypt *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEncrypt_WriteReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_AP_CTRL, 0);
}

void XEncrypt_InterruptGlobalEnable(XEncrypt *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEncrypt_WriteReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_GIE, 1);
}

void XEncrypt_InterruptGlobalDisable(XEncrypt *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XEncrypt_WriteReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_GIE, 0);
}

void XEncrypt_InterruptEnable(XEncrypt *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XEncrypt_ReadReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_IER);
    XEncrypt_WriteReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_IER, Register | Mask);
}

void XEncrypt_InterruptDisable(XEncrypt *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XEncrypt_ReadReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_IER);
    XEncrypt_WriteReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_IER, Register & (~Mask));
}

void XEncrypt_InterruptClear(XEncrypt *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    //XEncrypt_WriteReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_ISR, Mask);
}

u32 XEncrypt_InterruptGetEnabled(XEncrypt *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XEncrypt_ReadReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_IER);
}

u32 XEncrypt_InterruptGetStatus(XEncrypt *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    // Current Interrupt Clear Behavior is Clear on Read(COR).
    return XEncrypt_ReadReg(InstancePtr->Control_BaseAddress, XENCRYPT_CONTROL_ADDR_ISR);
}

